# World Watch 1.2 – stability release for current Android (15 / 16)

## Build
- targetSdk / compileSdk 34 -> **36** (Google Play requires API 36 for updates since 31 Aug 2026)
- Android Gradle Plugin 8.7.3 -> **8.13.2**, Gradle 8.10.2 -> **8.13** (needs JDK 17, Android Studio Narwhal 3 or newer)
- versionCode 3 / versionName 1.2
- No native code, so the Android 15+ 16 KB page-size requirement is already met

## Platform compatibility
- Edge-to-edge on every Android version (EdgeToEdge.enable) – identical look on 8-14 and the enforced mode on 15+
- Predictive back enabled; Back from Weather / Good News / World Watch returns to Alerts first
- Backup: data_extraction_rules + fullBackupContent (only the app's preferences are backed up)
- Removed status/navigation bar colour attributes that Android 15+ ignores

## Stability
- All feeds go through one hardened HTTP helper (User-Agent, status check, 6 MB cap); USGS and GDACS no longer use a bare connection
- Feeds load in parallel; last good result is shown when the network fails
- Duplicate headlines across feeds are merged; more RSS date formats parsed
- Link / share launches no longer crash when no browser or share target exists
- WorkManager back-off for failed background checks
- Animations pause when off-screen and respect the system "remove animations" setting

## Creative additions
- **Material You accent** (Android 12+): the accent follows the wallpaper; the cyber surfaces stay
- **Global threat level** in the Alerts HUD: LIVE • CALM / ELEVATED / SEVERE from the last 24 h
- Crisper haptic tick on Android 14+
