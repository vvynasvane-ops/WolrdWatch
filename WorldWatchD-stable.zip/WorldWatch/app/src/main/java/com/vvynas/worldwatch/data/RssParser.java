package com.vvynas.worldwatch.data;

import android.text.Html;
import android.util.Xml;

import com.vvynas.worldwatch.model.AlertItem;

import org.xmlpull.v1.XmlPullParser;

import java.io.ByteArrayInputStream;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;

/** Generic RSS 2.0 reader: headline, short snippet, link and date only (no full article text). */
public final class RssParser {
    private RssParser() {}

    private static final Set<String> FIELDS =
            new HashSet<>(Arrays.asList("title", "link", "pubDate", "description"));

    private static final String[] ALERT_WORDS = {
            "war", "attack", "strike", "missile", "sanction", "ceasefire", "coup", "invasion",
            "explosion", "killed", "troops", "escalat", "cyberattack", "hostage", "blockade"};

    public static List<AlertItem> fetch(String url, String source, boolean boostAlerts) throws Exception {
        byte[] data = Http.get(url);
        XmlPullParser p = Xml.newPullParser();
        p.setInput(new ByteArrayInputStream(data), null);

        List<AlertItem> out = new ArrayList<>();
        Map<String, String> f = new HashMap<>();
        int itemDepth = -1;
        int ev = p.getEventType();
        while (ev != XmlPullParser.END_DOCUMENT) {
            if (ev == XmlPullParser.START_TAG) {
                String n = p.getName();
                if (itemDepth < 0 && "item".equals(n)) {
                    itemDepth = p.getDepth();
                    f.clear();
                } else if (itemDepth >= 0 && p.getDepth() == itemDepth + 1 && FIELDS.contains(n)) {
                    f.put(n, p.nextText().trim());
                }
            } else if (ev == XmlPullParser.END_TAG && itemDepth >= 0
                    && p.getDepth() == itemDepth && "item".equals(p.getName())) {
                AlertItem a = toItem(f, source, boostAlerts);
                if (a != null) out.add(a);
                itemDepth = -1;
            }
            ev = p.next();
        }
        return out;
    }

    private static AlertItem toItem(Map<String, String> f, String source, boolean boost) {
        String title = clean(f.getOrDefault("title", ""));
        if (title.isEmpty()) return null;

        String summary = clean(f.getOrDefault("description", ""));
        if (summary.length() > 180) summary = summary.substring(0, 177).trim() + "\u2026";

        long time = parseDate(f.getOrDefault("pubDate", ""));

        int sev = AlertItem.MEDIUM;
        if (boost) {
            String t = title.toLowerCase(Locale.ROOT);
            for (String w : ALERT_WORDS) {
                if (t.contains(w)) { sev = AlertItem.HIGH; break; }
            }
        }
        String link = f.getOrDefault("link", "").replace("http://", "https://");
        return new AlertItem(title, summary, source, link, time, sev, true);
    }

    private static final String[] DATE_FORMATS = {
            "EEE, dd MMM yyyy HH:mm:ss z",    // GMT / UTC
            "EEE, dd MMM yyyy HH:mm:ss Z",    // +0100
            "dd MMM yyyy HH:mm:ss z"};        // weekday omitted

    /** RFC 822 date as used by RSS; falls back to "now" so a bad date never drops an item. */
    static long parseDate(String raw) {
        String v = raw == null ? "" : raw.trim();
        for (String pattern : DATE_FORMATS) {
            try {
                SimpleDateFormat fmt = new SimpleDateFormat(pattern, Locale.US);   // not thread-safe: one per call
                return fmt.parse(v).getTime();
            } catch (Exception ignored) { }
        }
        return System.currentTimeMillis();
    }

    private static String clean(String s) {
        return Html.fromHtml(s, Html.FROM_HTML_MODE_COMPACT).toString()
                .replace("\uFFFC", "").replaceAll("\\s+", " ").trim();
    }
}
