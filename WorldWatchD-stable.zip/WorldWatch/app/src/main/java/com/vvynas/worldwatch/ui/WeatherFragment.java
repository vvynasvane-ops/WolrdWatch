package com.vvynas.worldwatch.ui;

import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;

import com.vvynas.worldwatch.R;
import com.vvynas.worldwatch.data.Prefs;
import com.vvynas.worldwatch.data.WeatherRepository;

import java.text.SimpleDateFormat;
import java.util.Locale;

public class WeatherFragment extends Fragment {
    private SwipeRefreshLayout swipe;
    private TextView place, emoji, temp, cond, details, status;
    private View hero;
    private LinearLayout days;

    @Nullable @Override
    public View onCreateView(@NonNull LayoutInflater i, @Nullable ViewGroup c, @Nullable Bundle s) {
        return i.inflate(R.layout.fragment_weather, c, false);
    }

    @Override
    public void onViewCreated(@NonNull View v, @Nullable Bundle s) {
        super.onViewCreated(v, s);
        swipe = v.findViewById(R.id.swipe);
        hero = v.findViewById(R.id.hero);
        place = v.findViewById(R.id.place);
        emoji = v.findViewById(R.id.emoji);
        temp = v.findViewById(R.id.temp);
        cond = v.findViewById(R.id.cond);
        details = v.findViewById(R.id.details);
        status = v.findViewById(R.id.status);
        days = v.findViewById(R.id.days);
        swipe.setOnRefreshListener(() -> load(true));
        v.findViewById(R.id.attr).setOnClickListener(x -> {
            try {
                startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("https://open-meteo.com/")));
            } catch (ActivityNotFoundException e) {
                Toast.makeText(requireContext(), R.string.no_app_for_link, Toast.LENGTH_SHORT).show();
            }
        });
        Fonts.apply(v);
    }

    @Override
    public void onResume() {
        super.onResume();
        load(false);
    }

    /** Formats a Celsius value in the user's preferred unit. */
    private String t(double celsius) {
        if (Prefs.tempF(requireContext())) {
            return String.format(Locale.getDefault(), "%.0f\u00B0F", celsius * 9.0 / 5.0 + 32.0);
        }
        return String.format(Locale.getDefault(), "%.0f\u00B0C", celsius);
    }

    private void load(boolean force) {
        swipe.setRefreshing(true);
        WeatherRepository.load(requireContext(), force, (f, err) -> {
            if (!isAdded() || getView() == null) return;
            swipe.setRefreshing(false);
            days.removeAllViews();
            if (f == null) {
                hero.setVisibility(View.GONE);
                status.setVisibility(View.VISIBLE);
                status.setText(WeatherRepository.NO_CITY.equals(err) ? R.string.weather_no_city
                        : WeatherRepository.CITY_NOT_FOUND.equals(err) ? R.string.weather_city_not_found
                        : R.string.error_network);
                return;
            }
            hero.setVisibility(View.VISIBLE);
            status.setVisibility(View.GONE);
            place.setText(f.place);
            emoji.setText(WeatherRepository.emoji(f.code));
            temp.setText(t(f.temp));
            cond.setText(WeatherRepository.describe(f.code));
            details.setText(getString(R.string.weather_details, f.wind, f.humidity));

            SimpleDateFormat in = new SimpleDateFormat("yyyy-MM-dd", Locale.US);
            SimpleDateFormat out = new SimpleDateFormat("EEE d MMM", Locale.getDefault());
            LayoutInflater inflater = LayoutInflater.from(requireContext());
            for (WeatherRepository.Day d : f.days) {
                String label = d.date;
                try { label = out.format(in.parse(d.date)); } catch (Exception ignored) { }
                View row = inflater.inflate(R.layout.item_forecast_day, days, false);
                ((TextView) row.findViewById(R.id.f_emoji)).setText(WeatherRepository.emoji(d.code));
                ((TextView) row.findViewById(R.id.f_day)).setText(label);
                ((TextView) row.findViewById(R.id.f_cond)).setText(WeatherRepository.describe(d.code));
                ((TextView) row.findViewById(R.id.f_temps)).setText(t(d.max) + " / " + t(d.min));
                ((TextView) row.findViewById(R.id.f_rain)).setText(getString(R.string.weather_rain, d.rain));
                Fonts.apply(row);
                days.addView(row);
            }
        });
    }
}
