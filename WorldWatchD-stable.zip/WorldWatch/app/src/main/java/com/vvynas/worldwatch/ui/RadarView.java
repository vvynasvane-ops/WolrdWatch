package com.vvynas.worldwatch.ui;

import android.animation.ValueAnimator;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.SweepGradient;
import android.util.AttributeSet;
import android.view.View;
import android.view.animation.LinearInterpolator;

import com.vvynas.worldwatch.data.Prefs;

/** Animated radar sweep used as the scanning / empty state. */
public class RadarView extends View {
    private final Paint ring = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint sweep = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint dot = new Paint(Paint.ANTI_ALIAS_FLAG);
    private ValueAnimator anim;
    private float angle;
    private int color;
    private static final float[][] BLIPS = {{0.55f, 40f}, {0.3f, 150f}, {0.75f, 250f}};

    public RadarView(Context c) { this(c, null); }

    public RadarView(Context c, AttributeSet a) {
        super(c, a);
        float d = getResources().getDisplayMetrics().density;
        ring.setStyle(Paint.Style.STROKE);
        ring.setStrokeWidth(1.5f * d);
        sweep.setStyle(Paint.Style.FILL);
        dot.setStyle(Paint.Style.FILL);
    }

    @Override
    protected void onSizeChanged(int w, int h, int ow, int oh) {
        super.onSizeChanged(w, h, ow, oh);
        color = ThemeHelper.primary(getContext());
        sweep.setShader(new SweepGradient(w / 2f, h / 2f,
                new int[]{ThemeHelper.withAlpha(color, 0), ThemeHelper.withAlpha(color, 150)},
                new float[]{0.7f, 1f}));
    }

    @Override
    public void onVisibilityAggregated(boolean isVisible) {
        super.onVisibilityAggregated(isVisible);
        if (isVisible) start(); else stop();
    }

    private void start() {
        if (anim != null || Prefs.reduceMotion(getContext()) || !ValueAnimator.areAnimatorsEnabled()) return;
        anim = ValueAnimator.ofFloat(0f, 360f);
        anim.setDuration(2600);
        anim.setInterpolator(new LinearInterpolator());
        anim.setRepeatCount(ValueAnimator.INFINITE);
        anim.addUpdateListener(a -> {
            angle = (float) a.getAnimatedValue();
            invalidate();
        });
        anim.start();
    }

    private void stop() {
        if (anim != null) anim.cancel();
        anim = null;
    }

    @Override
    protected void onDetachedFromWindow() {
        stop();
        super.onDetachedFromWindow();
    }

    @Override
    protected void onDraw(Canvas c) {
        float cx = getWidth() / 2f, cy = getHeight() / 2f;
        float r = Math.min(cx, cy) - 4 * getResources().getDisplayMetrics().density;
        ring.setColor(ThemeHelper.withAlpha(color, 120));
        for (int i = 1; i <= 3; i++) c.drawCircle(cx, cy, r * i / 3f, ring);
        c.drawLine(cx - r, cy, cx + r, cy, ring);
        c.drawLine(cx, cy - r, cx, cy + r, ring);

        c.save();
        c.rotate(angle, cx, cy);
        c.drawCircle(cx, cy, r, sweep);
        ring.setColor(color);
        c.drawLine(cx, cy, cx + r, cy, ring);
        c.restore();

        dot.setColor(color);
        double rad;
        for (float[] b : BLIPS) {
            rad = Math.toRadians(b[1]);
            c.drawCircle((float) (cx + Math.cos(rad) * r * b[0]), (float) (cy + Math.sin(rad) * r * b[0]),
                    3 * getResources().getDisplayMetrics().density, dot);
        }
    }
}
