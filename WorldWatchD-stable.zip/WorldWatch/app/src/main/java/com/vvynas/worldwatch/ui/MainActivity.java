package com.vvynas.worldwatch.ui;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;

import androidx.activity.OnBackPressedCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;

import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.android.material.dialog.MaterialAlertDialogBuilder;
import com.vvynas.worldwatch.R;
import com.vvynas.worldwatch.data.Prefs;
import com.vvynas.worldwatch.model.AlertItem;
import com.vvynas.worldwatch.notify.NotifyScheduler;

public class MainActivity extends BaseActivity {
    public static final String EXTRA_TAB = "tab";

    private BottomNavigationView nav;

    /** Back from any other tab returns to Alerts first, then leaves the app. */
    private final OnBackPressedCallback backToHome = new OnBackPressedCallback(false) {
        @Override public void handleOnBackPressed() { nav.setSelectedItemId(R.id.nav_alerts); }
    };

    private final ActivityResultLauncher<String> notifPermission =
            registerForActivityResult(new ActivityResultContracts.RequestPermission(), this::onNotifPermission);

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        setSupportActionBar(findViewById(R.id.toolbar));

        getOnBackPressedDispatcher().addCallback(this, backToHome);

        nav = findViewById(R.id.bottom_nav);
        nav.setOnItemSelectedListener(item -> {
            int id = item.getItemId();
            backToHome.setEnabled(id != R.id.nav_alerts);
            String type = id == R.id.nav_watch ? AlertItem.WATCH
                    : id == R.id.nav_good ? AlertItem.GOOD : AlertItem.ALERT;
            Fragment f = id == R.id.nav_weather ? new WeatherFragment() : FeedFragment.newInstance(type);
            getSupportFragmentManager().beginTransaction()
                    .replace(R.id.container, f)
                    .commit();
            ThemeHelper.haptic(nav);
            return true;
        });
        Fonts.apply(findViewById(android.R.id.content));

        if (savedInstanceState == null) {
            nav.setSelectedItemId(tabFor(getIntent()));
            nav.post(this::maybeAskForNotifications);
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        backToHome.setEnabled(nav.getSelectedItemId() != R.id.nav_alerts);
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        nav.setSelectedItemId(tabFor(intent));
    }

    private int tabFor(Intent intent) {
        String tab = intent != null ? intent.getStringExtra(EXTRA_TAB) : null;
        return "watch".equals(tab) ? R.id.nav_watch : R.id.nav_alerts;
    }

    /** One-time prompt explaining notifications before the system permission dialog. */
    private void maybeAskForNotifications() {
        if (Prefs.onboarded(this) || isFinishing()) return;
        new MaterialAlertDialogBuilder(this)
                .setTitle(R.string.onboard_title)
                .setMessage(R.string.onboard_msg)
                .setCancelable(false)
                .setPositiveButton(R.string.onboard_yes, (d, w) -> {
                    Prefs.setOnboarded(this);
                    if (Build.VERSION.SDK_INT >= 33 && ContextCompat.checkSelfPermission(this,
                            Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
                        notifPermission.launch(Manifest.permission.POST_NOTIFICATIONS);
                    } else {
                        onNotifPermission(true);
                    }
                })
                .setNegativeButton(R.string.onboard_no, (d, w) -> Prefs.setOnboarded(this))
                .show();
    }

    private void onNotifPermission(boolean granted) {
        if (!granted) return;
        Prefs.setNotifEnabled(this, true);
        Prefs.setSeenInit(this, false);
        NotifyScheduler.schedule(this);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        if (item.getItemId() == R.id.action_settings) {
            startActivity(new Intent(this, SettingsActivity.class));
            return true;
        }
        return super.onOptionsItemSelected(item);
    }
}
