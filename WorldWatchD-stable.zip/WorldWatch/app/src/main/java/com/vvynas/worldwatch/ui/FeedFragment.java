package com.vvynas.worldwatch.ui;

import android.animation.ObjectAnimator;
import android.animation.PropertyValuesHolder;
import android.animation.ValueAnimator;
import android.content.Context;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.AnimationUtils;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;

import com.google.android.material.button.MaterialButton;
import com.google.android.material.button.MaterialButtonToggleGroup;
import com.vvynas.worldwatch.R;
import com.vvynas.worldwatch.data.AlertRepository;
import com.vvynas.worldwatch.data.Bookmarks;
import com.vvynas.worldwatch.data.Prefs;
import com.vvynas.worldwatch.model.AlertItem;

import java.text.DateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class FeedFragment extends Fragment {
    private static final String ARG_TYPE = "type";
    private static final int F_ALL = 0, F_CRIT = 1, F_HIGH = 2, F_MED = 3, F_SAVED = 4;

    private SwipeRefreshLayout swipe;
    private RecyclerView rv;
    private View emptyBox, liveDot;
    private TextView empty, hudCount, hudSync, hudTitle;
    private final AlertAdapter adapter = new AlertAdapter();
    private String type;
    private List<AlertItem> loaded = new ArrayList<>();
    private boolean loadedOnce;
    private boolean lastError;
    private int filter = F_ALL;
    private String query = "";
    private long syncedAt;
    private ObjectAnimator pulse;

    public static FeedFragment newInstance(String type) {
        FeedFragment f = new FeedFragment();
        Bundle b = new Bundle();
        b.putString(ARG_TYPE, type);
        f.setArguments(b);
        return f;
    }

    @Nullable @Override
    public View onCreateView(@NonNull LayoutInflater i, @Nullable ViewGroup c, @Nullable Bundle s) {
        return i.inflate(R.layout.fragment_feed, c, false);
    }

    @Override
    public void onViewCreated(@NonNull View v, @Nullable Bundle s) {
        super.onViewCreated(v, s);
        type = requireArguments().getString(ARG_TYPE, AlertItem.ALERT);
        final boolean alerts = AlertItem.ALERT.equals(type);
        swipe = v.findViewById(R.id.swipe);
        emptyBox = v.findViewById(R.id.empty_box);
        empty = v.findViewById(R.id.empty);
        hudCount = v.findViewById(R.id.hud_count);
        hudSync = v.findViewById(R.id.hud_sync);
        hudTitle = v.findViewById(R.id.hud_title);
        liveDot = v.findViewById(R.id.live_dot);
        rv = v.findViewById(R.id.list);
        rv.setLayoutManager(new LinearLayoutManager(requireContext()));
        rv.setAdapter(adapter);
        adapter.setOnSavedChanged(() -> { if (filter == F_SAVED) applyFilters(false); });
        swipe.setOnRefreshListener(() -> load(true));

        // filter segments (news feeds only have All / Breaking / Saved)
        MaterialButtonToggleGroup group = v.findViewById(R.id.filter_group);
        if (!alerts) {
            v.findViewById(R.id.btn_f_critical).setVisibility(View.GONE);
            v.findViewById(R.id.btn_f_medium).setVisibility(View.GONE);
            ((MaterialButton) v.findViewById(R.id.btn_f_high)).setText(R.string.filter_breaking);
        }
        group.check(R.id.btn_f_all);
        group.addOnButtonCheckedListener((g, id, checked) -> {
            if (!checked) return;
            filter = id == R.id.btn_f_critical ? F_CRIT : id == R.id.btn_f_high ? F_HIGH
                    : id == R.id.btn_f_medium ? F_MED : id == R.id.btn_f_saved ? F_SAVED : F_ALL;
            ThemeHelper.haptic(g);
            applyFilters(true);
        });

        // live search
        ((TextView) v.findViewById(R.id.search)).addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int a, int b, int c) { }
            @Override public void onTextChanged(CharSequence s, int a, int b, int c) { }
            @Override public void afterTextChanged(Editable e) {
                query = e.toString().trim().toLowerCase(Locale.ROOT);
                applyFilters(false);
            }
        });

        Fonts.apply(v);
        updateHud(0);
    }

    @Override
    public void onResume() {
        super.onResume();
        startPulse();
        load(false);
    }

    @Override
    public void onPause() {
        stopPulse();   // no animation work while the screen is not visible
        super.onPause();
    }

    @Override
    public void onDestroyView() {
        stopPulse();
        super.onDestroyView();
    }

    private void stopPulse() {
        if (pulse != null) pulse.cancel();
        pulse = null;
        if (liveDot != null) { liveDot.setAlpha(1f); liveDot.setScaleX(1f); liveDot.setScaleY(1f); }
    }

    private void startPulse() {
        stopPulse();
        if (Prefs.reduceMotion(requireContext()) || !ValueAnimator.areAnimatorsEnabled()) return;
        pulse = ObjectAnimator.ofPropertyValuesHolder(liveDot,
                PropertyValuesHolder.ofFloat(View.ALPHA, 1f, 0.2f),
                PropertyValuesHolder.ofFloat(View.SCALE_X, 1f, 1.5f),
                PropertyValuesHolder.ofFloat(View.SCALE_Y, 1f, 1.5f));
        pulse.setDuration(900);
        pulse.setRepeatCount(ObjectAnimator.INFINITE);
        pulse.setRepeatMode(ObjectAnimator.REVERSE);
        pulse.start();
    }

    private void load(boolean force) {
        swipe.setRefreshing(force || loadedOnce);
        final Context app = requireContext().getApplicationContext();
        AlertRepository.load(app, type, force, (items, error) -> {
            if (!isAdded() || getView() == null) return;
            swipe.setRefreshing(false);
            int min = Prefs.minSeverity(app);
            List<AlertItem> shown = new ArrayList<>();
            for (AlertItem a : items) {
                if (AlertItem.GOOD.equals(type) || a.severity >= min) shown.add(a);
            }
            loaded = shown;
            loadedOnce = true;
            lastError = error != null;
            if (error == null) syncedAt = System.currentTimeMillis();
            applyFilters(true);
        });
    }

    private void applyFilters(boolean animate) {
        final Context ctx = requireContext();
        List<AlertItem> src = filter == F_SAVED ? Bookmarks.all(ctx) : loaded;
        List<AlertItem> shown = new ArrayList<>();
        for (AlertItem a : src) {
            if (filter == F_CRIT && a.severity < AlertItem.CRITICAL) continue;
            if (filter == F_HIGH && a.severity != AlertItem.HIGH) continue;
            if (filter == F_MED && a.severity != AlertItem.MEDIUM) continue;
            if (!query.isEmpty()) {
                String hay = (a.title + " " + a.summary + " " + a.source).toLowerCase(Locale.ROOT);
                if (!hay.contains(query)) continue;
            }
            shown.add(a);
        }

        boolean motion = animate && !Prefs.reduceMotion(ctx);
        rv.setLayoutAnimation(motion
                ? AnimationUtils.loadLayoutAnimation(ctx, R.anim.layout_stagger) : null);
        adapter.submit(shown);
        if (motion) rv.scheduleLayoutAnimation();

        updateHud(shown.size());
        updateThreat();
        emptyBox.setVisibility(shown.isEmpty() ? View.VISIBLE : View.GONE);
        if (shown.isEmpty()) {
            empty.setText(filter == F_SAVED && query.isEmpty() ? R.string.empty_saved
                    : !query.isEmpty() ? R.string.empty_search
                    : !loadedOnce ? R.string.scanning
                    : lastError ? R.string.error_network : R.string.empty);
        }
    }

    /** Alerts tab only: a one-glance "global threat level" from the last 24 hours of live signals. */
    private void updateThreat() {
        if (!AlertItem.ALERT.equals(type) || hudTitle == null) return;
        long cutoff = System.currentTimeMillis() - 24L * 60 * 60 * 1000;
        int critical = 0, high = 0;
        for (AlertItem a : loaded) {
            if (a.time < cutoff) continue;
            if (a.severity >= AlertItem.CRITICAL) critical++;
            else if (a.severity == AlertItem.HIGH) high++;
        }
        int labelRes, colorRes;
        if (critical > 0) { labelRes = R.string.threat_severe; colorRes = R.color.sev_critical; }
        else if (high >= 3) { labelRes = R.string.threat_elevated; colorRes = R.color.sev_high; }
        else { labelRes = R.string.threat_calm; colorRes = -1; }
        hudTitle.setText(getString(R.string.threat_format, getString(labelRes)));
        hudTitle.setTextColor(colorRes == -1 ? ThemeHelper.primary(requireContext())
                : requireContext().getColor(colorRes));
    }

    private void updateHud(int count) {
        hudCount.setText(getResources().getQuantityString(R.plurals.signals, count, count));
        String t = syncedAt == 0 ? "--:--"
                : DateFormat.getTimeInstance(DateFormat.SHORT).format(new Date(syncedAt));
        hudSync.setText(getString(R.string.hud_sync, t));
    }
}
