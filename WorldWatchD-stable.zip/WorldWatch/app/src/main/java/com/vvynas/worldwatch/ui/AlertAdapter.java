package com.vvynas.worldwatch.ui;

import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.content.res.ColorStateList;
import android.os.Build;
import android.text.format.DateUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.card.MaterialCardView;
import com.vvynas.worldwatch.R;
import com.vvynas.worldwatch.data.Bookmarks;
import com.vvynas.worldwatch.data.Prefs;
import com.vvynas.worldwatch.model.AlertItem;

import java.util.ArrayList;
import java.util.List;

public class AlertAdapter extends RecyclerView.Adapter<AlertAdapter.VH> {
    private final List<AlertItem> items = new ArrayList<>();
    private Runnable onSavedChanged;

    public void setOnSavedChanged(Runnable r) { onSavedChanged = r; }

    public void submit(List<AlertItem> list) {
        items.clear();
        items.addAll(list);
        notifyDataSetChanged();
    }

    @NonNull @Override
    public VH onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_alert, parent, false);
        Fonts.apply(v);
        return new VH(v);
    }

    @Override
    public void onBindViewHolder(@NonNull VH h, int position) {
        final AlertItem a = items.get(position);
        final Context c = h.itemView.getContext();
        final float dp = c.getResources().getDisplayMetrics().density;

        int color, label;
        if (a.severity >= AlertItem.CRITICAL) { color = R.color.sev_critical; label = R.string.sev_critical; }
        else if (a.severity == AlertItem.HIGH) { color = R.color.sev_high; label = R.string.sev_high; }
        else { color = R.color.sev_medium; label = R.string.sev_medium; }
        final int sevColor = c.getColor(color);

        h.sev.setText(label);
        h.sev.setBackgroundTintList(ColorStateList.valueOf(sevColor));
        h.sev.setVisibility(a.news && a.severity < AlertItem.HIGH ? View.GONE : View.VISIBLE);
        h.title.setText(a.title);
        h.summary.setText(a.summary);
        h.meta.setText(a.source + " \u2022 " + DateUtils.getRelativeTimeSpanString(
                a.time, System.currentTimeMillis(), DateUtils.MINUTE_IN_MILLIS));

        // neon severity styling
        boolean strong = a.severity >= AlertItem.HIGH;
        h.bar.setBackgroundColor(sevColor);
        h.card.setStrokeColor(ThemeHelper.withAlpha(sevColor, strong ? 0xAA : 0x44));
        h.card.setCardElevation(strong ? 6 * dp : 0f);
        if (Build.VERSION.SDK_INT >= 28) {
            h.card.setOutlineSpotShadowColor(sevColor);
            h.card.setOutlineAmbientShadowColor(sevColor);
        }

        // user layout preferences
        boolean compact = Prefs.density(c) == 1;
        h.card.setRadius(ThemeHelper.cornerDp(Prefs.shape(c)) * dp);
        int pad = (int) ((compact ? 10 : 16) * dp);
        h.body.setPadding(pad, pad, pad, pad);
        h.summary.setVisibility(compact || a.summary == null || a.summary.isEmpty() ? View.GONE : View.VISIBLE);

        boolean fresh = System.currentTimeMillis() - a.time < DateUtils.HOUR_IN_MILLIS;
        h.fresh.setVisibility(fresh ? View.VISIBLE : View.GONE);

        h.save.setImageResource(Bookmarks.isSaved(c, a) ? R.drawable.ic_bookmark_filled : R.drawable.ic_bookmark);
        h.save.setOnClickListener(v -> {
            boolean now = Bookmarks.toggle(c, a);
            h.save.setImageResource(now ? R.drawable.ic_bookmark_filled : R.drawable.ic_bookmark);
            ThemeHelper.haptic(v);
            if (onSavedChanged != null) onSavedChanged.run();
        });
        h.share.setOnClickListener(v -> {
            ThemeHelper.haptic(v);
            Intent send = new Intent(Intent.ACTION_SEND)
                    .setType("text/plain")
                    .putExtra(Intent.EXTRA_TEXT, a.title + (a.url != null && !a.url.isEmpty() ? "\n" + a.url : ""));
            launch(c, Intent.createChooser(send, c.getString(R.string.share_via)));
        });
        h.itemView.setOnClickListener(v -> {
            if (a.url != null && a.url.startsWith("https://")) {
                launch(c, new Intent(Intent.ACTION_VIEW, Uri.parse(a.url)));
            }
        });
    }

    @Override public int getItemCount() { return items.size(); }

    /** Never crash on devices without a browser / share target. */
    private static void launch(Context c, Intent i) {
        try {
            c.startActivity(i);
        } catch (ActivityNotFoundException e) {
            Toast.makeText(c, R.string.no_app_for_link, Toast.LENGTH_SHORT).show();
        }
    }

    static class VH extends RecyclerView.ViewHolder {
        final MaterialCardView card;
        final View bar, body;
        final TextView sev, fresh, title, summary, meta;
        final ImageButton share, save;

        VH(@NonNull View v) {
            super(v);
            card = v.findViewById(R.id.card);
            bar = v.findViewById(R.id.bar);
            body = v.findViewById(R.id.body);
            sev = v.findViewById(R.id.sev);
            fresh = v.findViewById(R.id.fresh);
            title = v.findViewById(R.id.title);
            summary = v.findViewById(R.id.summary);
            meta = v.findViewById(R.id.meta);
            share = v.findViewById(R.id.share);
            save = v.findViewById(R.id.save);
        }
    }
}
