package com.vvynas.worldwatch.ui;

import android.content.Context;
import android.content.res.Configuration;
import android.os.Bundle;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;

/** Applies accent / AMOLED overlays and the user's font size, and rebuilds when style prefs change. */
public abstract class BaseActivity extends AppCompatActivity {
    private String stamp;

    @Override
    protected void attachBaseContext(Context base) {
        super.attachBaseContext(ThemeHelper.withFontScale(base));
    }

    @Override
    public void applyOverrideConfiguration(Configuration overrideConfiguration) {
        if (overrideConfiguration != null) {
            int uiMode = overrideConfiguration.uiMode;
            overrideConfiguration.setTo(getBaseContext().getResources().getConfiguration());
            overrideConfiguration.uiMode = uiMode;
        }
        super.applyOverrideConfiguration(overrideConfiguration);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        ThemeHelper.applyOverlays(this);
        stamp = ThemeHelper.stamp(this);
        // Android 15+ forces edge-to-edge; this gives Android 8-14 the identical look.
        EdgeToEdge.enable(this);
        super.onCreate(savedInstanceState);
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (stamp != null && !stamp.equals(ThemeHelper.stamp(this))) recreate();
    }
}
