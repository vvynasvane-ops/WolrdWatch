@echo off
call gradlew.bat clean
call gradlew.bat assembleDebug
echo.
echo APK: app\build\outputs\apk\debug\app-debug.apk
pause
