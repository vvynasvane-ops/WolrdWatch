package com.vvynas.worldwatch.data;

import android.content.Context;
import android.content.SharedPreferences;

import java.util.ArrayList;
import java.util.Collection;
import java.util.LinkedHashSet;
import java.util.List;

public final class Prefs {
    private Prefs() {}

    public static final int MODE_SYSTEM = 0, MODE_LIGHT = 1, MODE_DARK = 2, MODE_AMOLED = 3;

    static SharedPreferences sp(Context c) {
        return c.getApplicationContext().getSharedPreferences("worldwatch", Context.MODE_PRIVATE);
    }

    // ---- feed preferences ----
    public static int minSeverity(Context c) { return sp(c).getInt("min_severity", 1); }

    public static String city(Context c) { return sp(c).getString("city", ""); }

    /** Comma-separated interest keywords; filters the World Watch and Good News tabs. */
    public static String keywords(Context c) { return sp(c).getString("keywords", ""); }

    public static void save(Context c, int minSeverity, String city, String keywords) {
        String newCity = city.trim();
        SharedPreferences.Editor e = sp(c).edit()
                .putInt("min_severity", minSeverity)
                .putString("keywords", keywords.trim());
        if (!newCity.equalsIgnoreCase(city(c))) e.remove("geo_city").remove("lat").remove("lon").remove("place");
        e.putString("city", newCity).apply();
        AlertRepository.invalidate();
    }

    // ---- appearance ----
    public static int themeMode(Context c) { return sp(c).getInt("theme_mode", MODE_SYSTEM); }
    public static void setThemeMode(Context c, int v) { sp(c).edit().putInt("theme_mode", v).apply(); }

    public static int accent(Context c) { return sp(c).getInt("accent", 0); }
    public static void setAccent(Context c, int v) { sp(c).edit().putInt("accent", v).apply(); }

    public static int font(Context c) { return sp(c).getInt("font", 0); }
    public static void setFont(Context c, int v) { sp(c).edit().putInt("font", v).apply(); }

    public static int fontScale(Context c) { return sp(c).getInt("font_scale", 1); }
    public static void setFontScale(Context c, int v) { sp(c).edit().putInt("font_scale", v).apply(); }

    /** 0 = comfortable, 1 = compact */
    public static int density(Context c) { return sp(c).getInt("density", 0); }
    public static void setDensity(Context c, int v) { sp(c).edit().putInt("density", v).apply(); }

    /** 0 = sharp, 1 = soft, 2 = round */
    public static int shape(Context c) { return sp(c).getInt("shape", 1); }
    public static void setShape(Context c, int v) { sp(c).edit().putInt("shape", v).apply(); }

    public static boolean tempF(Context c) { return sp(c).getBoolean("temp_f", false); }
    public static void setTempF(Context c, boolean v) { sp(c).edit().putBoolean("temp_f", v).apply(); }

    public static boolean reduceMotion(Context c) { return sp(c).getBoolean("reduce_motion", false); }
    public static void setReduceMotion(Context c, boolean v) { sp(c).edit().putBoolean("reduce_motion", v).apply(); }

    public static boolean haptics(Context c) { return sp(c).getBoolean("haptics", true); }
    public static void setHaptics(Context c, boolean v) { sp(c).edit().putBoolean("haptics", v).apply(); }

    // ---- notifications ----
    public static boolean onboarded(Context c) { return sp(c).getBoolean("onboarded", false); }
    public static void setOnboarded(Context c) { sp(c).edit().putBoolean("onboarded", true).apply(); }

    public static boolean notifEnabled(Context c) { return sp(c).getBoolean("notif_enabled", false); }
    public static void setNotifEnabled(Context c, boolean v) { sp(c).edit().putBoolean("notif_enabled", v).apply(); }

    /** Minimum severity (1 medium, 2 high, 3 critical) that triggers a notification. */
    public static int notifMinSeverity(Context c) { return sp(c).getInt("notif_min_sev", 2); }
    public static void setNotifMinSeverity(Context c, int v) { sp(c).edit().putInt("notif_min_sev", v).apply(); }

    public static boolean notifNews(Context c) { return sp(c).getBoolean("notif_news", true); }
    public static void setNotifNews(Context c, boolean v) { sp(c).edit().putBoolean("notif_news", v).apply(); }

    public static int notifInterval(Context c) { return sp(c).getInt("notif_interval", 2); }
    public static void setNotifInterval(Context c, int v) { sp(c).edit().putInt("notif_interval", v).apply(); }

    public static boolean quietOn(Context c) { return sp(c).getBoolean("quiet_on", false); }
    public static void setQuietOn(Context c, boolean v) { sp(c).edit().putBoolean("quiet_on", v).apply(); }

    /** Minutes after midnight. */
    public static int quietStart(Context c) { return sp(c).getInt("quiet_start", 22 * 60); }
    public static int quietEnd(Context c) { return sp(c).getInt("quiet_end", 7 * 60); }
    public static void setQuietStart(Context c, int v) { sp(c).edit().putInt("quiet_start", v).apply(); }
    public static void setQuietEnd(Context c, int v) { sp(c).edit().putInt("quiet_end", v).apply(); }

    public static boolean seenInit(Context c) { return sp(c).getBoolean("seen_init", false); }
    public static void setSeenInit(Context c, boolean v) { sp(c).edit().putBoolean("seen_init", v).apply(); }

    /** Keys of alerts already notified (or baselined), oldest first. */
    public static List<String> seenIds(Context c) {
        String raw = sp(c).getString("seen_ids", "");
        List<String> out = new ArrayList<>();
        if (raw.isEmpty()) return out;
        for (String s : raw.split("\n")) if (!s.isEmpty()) out.add(s);
        return out;
    }

    public static void setSeenIds(Context c, Collection<String> ids) {
        LinkedHashSet<String> set = new LinkedHashSet<>(ids);
        List<String> l = new ArrayList<>(set);
        if (l.size() > 400) l = l.subList(l.size() - 400, l.size());
        sp(c).edit().putString("seen_ids", String.join("\n", l)).apply();
    }

    // ---- cached geocoding result for the home city ----
    public static boolean hasGeo(Context c, String city) {
        SharedPreferences s = sp(c);
        return s.contains("lat") && s.contains("lon") && city.equalsIgnoreCase(s.getString("geo_city", ""));
    }

    public static double lat(Context c) { return Double.parseDouble(sp(c).getString("lat", "0")); }

    public static double lon(Context c) { return Double.parseDouble(sp(c).getString("lon", "0")); }

    public static String place(Context c) { return sp(c).getString("place", ""); }

    public static void saveGeo(Context c, String city, double lat, double lon, String place) {
        sp(c).edit().putString("geo_city", city).putString("lat", Double.toString(lat))
                .putString("lon", Double.toString(lon)).putString("place", place).apply();
    }
}
