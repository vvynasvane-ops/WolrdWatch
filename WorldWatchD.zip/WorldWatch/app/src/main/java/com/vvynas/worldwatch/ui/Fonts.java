package com.vvynas.worldwatch.ui;

import android.content.Context;
import android.graphics.Typeface;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.core.content.res.ResourcesCompat;

import com.google.android.material.textfield.TextInputLayout;
import com.vvynas.worldwatch.R;
import com.vvynas.worldwatch.data.Prefs;

/** The eight selectable font families and a helper that applies one to a view tree. */
public final class Fonts {
    private Fonts() {}

    public static final String[] NAMES = {
            "Orbitron", "Rajdhani", "Exo 2", "Audiowide",
            "Share Tech Mono", "Chakra Petch", "Oxanium", "System Default"};

    private static final int[] RES = {
            R.font.orbitron, R.font.rajdhani, R.font.exo2, R.font.audiowide,
            R.font.share_tech_mono, R.font.chakra_petch, R.font.oxanium, 0};

    /** @return the typeface for index i, or null for the system default. */
    public static Typeface get(Context c, int i) {
        if (i < 0 || i >= RES.length || RES[i] == 0) return null;
        try {
            return ResourcesCompat.getFont(c, RES[i]);
        } catch (Exception e) {
            return null;
        }
    }

    public static Typeface current(Context c) { return get(c, Prefs.font(c)); }

    public static void apply(View root) {
        if (root == null) return;
        apply(root, current(root.getContext()));
    }

    public static void apply(View v, Typeface tf) {
        if (v == null || tf == null) return;
        if (v instanceof TextInputLayout) ((TextInputLayout) v).setTypeface(tf);
        if (v instanceof TextView) {
            TextView t = (TextView) v;
            Typeface cur = t.getTypeface();
            t.setTypeface(tf, cur != null ? cur.getStyle() : Typeface.NORMAL);
        }
        if (v instanceof ViewGroup) {
            ViewGroup g = (ViewGroup) v;
            for (int i = 0; i < g.getChildCount(); i++) apply(g.getChildAt(i), tf);
        }
    }
}
