package com.vvynas.worldwatch.notify;

import android.content.Context;

import androidx.work.Constraints;
import androidx.work.ExistingPeriodicWorkPolicy;
import androidx.work.NetworkType;
import androidx.work.PeriodicWorkRequest;
import androidx.work.WorkManager;

import com.vvynas.worldwatch.data.Prefs;

import java.util.concurrent.TimeUnit;

public final class NotifyScheduler {
    private NotifyScheduler() {}

    private static final String WORK = "ww_alert_poll";
    public static final int[] INTERVAL_MIN = {15, 30, 60, 180, 360};

    /** (Re)schedules background checks from the saved preferences, or cancels them when disabled. */
    public static void schedule(Context c) {
        Context app = c.getApplicationContext();
        if (!Prefs.notifEnabled(app)) {
            cancel(app);
            return;
        }
        int idx = Math.max(0, Math.min(INTERVAL_MIN.length - 1, Prefs.notifInterval(app)));
        Constraints cons = new Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build();
        PeriodicWorkRequest req = new PeriodicWorkRequest.Builder(
                AlertWorker.class, INTERVAL_MIN[idx], TimeUnit.MINUTES)
                .setConstraints(cons)
                .build();
        WorkManager.getInstance(app).enqueueUniquePeriodicWork(WORK, ExistingPeriodicWorkPolicy.UPDATE, req);
    }

    public static void cancel(Context c) {
        WorkManager.getInstance(c.getApplicationContext()).cancelUniqueWork(WORK);
    }
}
