package com.vvynas.worldwatch.model;

public final class AlertItem {
    public static final String ALERT = "alert";
    public static final String WATCH = "watch";
    public static final String GOOD = "good";

    public static final int MEDIUM = 1, HIGH = 2, CRITICAL = 3;

    public final String title, summary, source, url;
    public final long time;
    public final int severity;
    /** true for ordinary news headlines (severity label is hidden unless boosted to HIGH). */
    public final boolean news;

    public AlertItem(String title, String summary, String source, String url, long time, int severity) {
        this(title, summary, source, url, time, severity, false);
    }

    public AlertItem(String title, String summary, String source, String url, long time,
                     int severity, boolean news) {
        this.title = title;
        this.summary = summary;
        this.source = source;
        this.url = url;
        this.time = time;
        this.severity = severity;
        this.news = news;
    }

    /** Stable identity used for bookmarks and notification de-duplication. */
    public String key() {
        return (url != null && !url.isEmpty()) ? url : title + "|" + time;
    }
}
