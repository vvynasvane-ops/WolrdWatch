package com.vvynas.worldwatch;

import android.app.Application;

import com.vvynas.worldwatch.notify.Notifier;
import com.vvynas.worldwatch.notify.NotifyScheduler;
import com.vvynas.worldwatch.ui.ThemeHelper;

public class WorldWatchApp extends Application {
    @Override
    public void onCreate() {
        super.onCreate();
        ThemeHelper.applyNightMode(this);
        Notifier.createChannels(this);
        NotifyScheduler.schedule(this);
    }
}
