package com.vvynas.worldwatch.notify;

import android.content.Context;

import androidx.annotation.NonNull;
import androidx.work.Worker;
import androidx.work.WorkerParameters;

import com.vvynas.worldwatch.data.AlertRepository;
import com.vvynas.worldwatch.data.Prefs;
import com.vvynas.worldwatch.model.AlertItem;

import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;

/** Periodically checks the live feeds and notifies about alerts the user has not seen yet. */
public class AlertWorker extends Worker {
    private static final long MAX_AGE_MS = 24L * 60 * 60 * 1000;

    public AlertWorker(@NonNull Context context, @NonNull WorkerParameters params) {
        super(context, params);
    }

    @NonNull
    @Override
    public Result doWork() {
        Context c = getApplicationContext();
        if (!Prefs.notifEnabled(c) || !Notifier.canPost(c)) return Result.success();
        if (Notifier.inQuietHours(c)) return Result.success();   // checked again after quiet hours end
        try {
            List<AlertItem> all = new ArrayList<>(AlertRepository.fetchAlertsBlocking());
            if (Prefs.notifNews(c)) all.addAll(AlertRepository.fetchBreakingBlocking(c));

            Set<String> seen = new LinkedHashSet<>(Prefs.seenIds(c));
            boolean baseline = !Prefs.seenInit(c);       // first run only records what already exists
            int min = Prefs.notifMinSeverity(c);
            long cutoff = System.currentTimeMillis() - MAX_AGE_MS;

            List<AlertItem> fresh = new ArrayList<>();
            for (AlertItem a : all) {
                if (!seen.add(a.key())) continue;
                if (!baseline && a.severity >= min && a.time >= cutoff) fresh.add(a);
            }
            Prefs.setSeenIds(c, seen);
            Prefs.setSeenInit(c, true);
            Notifier.post(c, fresh);
            return Result.success();
        } catch (Exception e) {
            return Result.retry();
        }
    }
}
