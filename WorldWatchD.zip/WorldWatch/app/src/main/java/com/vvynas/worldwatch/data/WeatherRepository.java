package com.vvynas.worldwatch.data;

import android.content.Context;
import android.os.Handler;
import android.os.Looper;

import org.json.JSONArray;
import org.json.JSONObject;

import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** Open-Meteo forecast + geocoding. Free, no API key; attribution (CC BY 4.0) is shown in the UI. */
public final class WeatherRepository {
    public static final String NO_CITY = "NO_CITY";
    public static final String CITY_NOT_FOUND = "CITY_NOT_FOUND";

    public static final class Day { public String date; public double max, min, rain; public int code; }

    public static final class Forecast {
        public String place;
        public double temp, wind;
        public int humidity, code;
        public final List<Day> days = new ArrayList<>();
    }

    public interface Callback { void onResult(Forecast f, String error); }

    private static final ExecutorService IO = Executors.newSingleThreadExecutor();
    private static final Handler MAIN = new Handler(Looper.getMainLooper());
    private static final long TTL = 30 * 60_000L;

    private static Forecast cache;
    private static String cacheKey = "";
    private static long cacheAt;

    private WeatherRepository() {}

    public static void load(Context ctx, boolean force, Callback cb) {
        final Context app = ctx.getApplicationContext();
        IO.execute(() -> {
            Forecast f = null;
            String err = null;
            try { f = fetch(app, force); }
            catch (Exception e) { err = String.valueOf(e.getMessage()); }
            final Forecast rf = f;
            final String re = err;
            MAIN.post(() -> cb.onResult(rf, re));
        });
    }

    private static Forecast fetch(Context c, boolean force) throws Exception {
        String city = Prefs.city(c);
        if (city.isEmpty()) throw new IllegalStateException(NO_CITY);
        String key = city.toLowerCase(Locale.ROOT);

        synchronized (WeatherRepository.class) {
            if (!force && cache != null && key.equals(cacheKey) && System.currentTimeMillis() - cacheAt < TTL) {
                return cache;
            }
        }

        if (!Prefs.hasGeo(c, city)) {
            String u = "https://geocoding-api.open-meteo.com/v1/search?count=1&language=en&format=json&name="
                    + URLEncoder.encode(city, "UTF-8");
            JSONArray res = new JSONObject(new String(Http.get(u), StandardCharsets.UTF_8)).optJSONArray("results");
            if (res == null || res.length() == 0) throw new IllegalStateException(CITY_NOT_FOUND);
            JSONObject r = res.getJSONObject(0);
            String country = r.optString("country", "");
            Prefs.saveGeo(c, city, r.getDouble("latitude"), r.getDouble("longitude"),
                    r.optString("name", city) + (country.isEmpty() ? "" : ", " + country));
        }

        String url = String.format(Locale.US,
                "https://api.open-meteo.com/v1/forecast?latitude=%.4f&longitude=%.4f"
                        + "&current=temperature_2m,weather_code,wind_speed_10m,relative_humidity_2m"
                        + "&daily=weather_code,temperature_2m_max,temperature_2m_min,precipitation_sum"
                        + "&forecast_days=7&timezone=auto", Prefs.lat(c), Prefs.lon(c));
        JSONObject root = new JSONObject(new String(Http.get(url), StandardCharsets.UTF_8));

        Forecast f = new Forecast();
        f.place = Prefs.place(c);
        JSONObject cur = root.getJSONObject("current");
        f.temp = cur.getDouble("temperature_2m");
        f.wind = cur.getDouble("wind_speed_10m");
        f.humidity = cur.getInt("relative_humidity_2m");
        f.code = cur.getInt("weather_code");

        JSONObject d = root.getJSONObject("daily");
        JSONArray time = d.getJSONArray("time"), max = d.getJSONArray("temperature_2m_max"),
                min = d.getJSONArray("temperature_2m_min"), rain = d.getJSONArray("precipitation_sum"),
                code = d.getJSONArray("weather_code");
        for (int i = 0; i < time.length(); i++) {
            Day day = new Day();
            day.date = time.getString(i);
            day.max = max.optDouble(i, 0);
            day.min = min.optDouble(i, 0);
            day.rain = rain.optDouble(i, 0);
            day.code = code.optInt(i, 0);
            f.days.add(day);
        }

        synchronized (WeatherRepository.class) {
            cache = f;
            cacheKey = key;
            cacheAt = System.currentTimeMillis();
        }
        return f;
    }

    /** Emoji for a WMO weather code. */
    public static String emoji(int code) {
        switch (code) {
            case 0: return "\u2600\uFE0F";
            case 1: return "\uD83C\uDF24\uFE0F";
            case 2: return "\u26C5";
            case 3: return "\u2601\uFE0F";
            case 45: case 48: return "\uD83C\uDF2B\uFE0F";
            case 51: case 53: case 55: case 56: case 57: return "\uD83C\uDF26\uFE0F";
            case 61: case 63: case 65: case 66: case 67: case 80: case 81: case 82: return "\uD83C\uDF27\uFE0F";
            case 71: case 73: case 75: case 77: return "\u2744\uFE0F";
            case 85: case 86: return "\uD83C\uDF28\uFE0F";
            case 95: case 96: case 99: return "\u26C8\uFE0F";
            default: return "\uD83C\uDF21\uFE0F";
        }
    }

    /** WMO weather interpretation codes used by Open-Meteo. */
    public static String describe(int code) {
        switch (code) {
            case 0: return "Clear sky";
            case 1: return "Mainly clear";
            case 2: return "Partly cloudy";
            case 3: return "Overcast";
            case 45: case 48: return "Fog";
            case 51: case 53: case 55: return "Drizzle";
            case 56: case 57: return "Freezing drizzle";
            case 61: case 63: case 65: return "Rain";
            case 66: case 67: return "Freezing rain";
            case 71: case 73: case 75: return "Snow";
            case 77: return "Snow grains";
            case 80: case 81: case 82: return "Rain showers";
            case 85: case 86: return "Snow showers";
            case 95: return "Thunderstorm";
            case 96: case 99: return "Thunderstorm with hail";
            default: return "Unknown";
        }
    }
}
