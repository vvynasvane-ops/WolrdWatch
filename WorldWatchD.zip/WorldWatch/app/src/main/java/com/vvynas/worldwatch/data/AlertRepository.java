package com.vvynas.worldwatch.data;

import android.content.Context;
import android.os.Handler;
import android.os.Looper;
import android.util.Xml;

import com.vvynas.worldwatch.model.AlertItem;

import org.json.JSONArray;
import org.json.JSONObject;
import org.xmlpull.v1.XmlPullParser;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Locale;
import java.util.Map;
import java.util.Set;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * Alerts tab: live USGS M4.5+ earthquakes plus GDACS (UN / European Commission) disaster
 * alerts. World Watch / Good News tabs read public RSS feeds. No API keys; results are cached.
 * GDACS earthquakes are skipped because USGS covers them.
 * Watch / Good tabs: clearly labelled placeholders until real feeds are wired in.
 */
public final class AlertRepository {
    public interface Callback { void onResult(List<AlertItem> items, String error); }

    private static final String USGS =
            "https://earthquake.usgs.gov/earthquakes/feed/v1.0/summary/4.5_day.geojson";
    private static final ExecutorService IO = Executors.newSingleThreadExecutor();
    private static final Handler MAIN = new Handler(Looper.getMainLooper());

    private AlertRepository() {}

    private static final String[][] WATCH_FEEDS = {
            {"BBC News", "https://feeds.bbci.co.uk/news/world/rss.xml"},
            {"Al Jazeera", "https://www.aljazeera.com/xml/rss/all.xml"},
            {"The Guardian", "https://www.theguardian.com/world/rss"}};
    private static final String[][] GOOD_FEEDS = {
            {"Good News Network", "https://www.goodnewsnetwork.org/feed/"},
            {"Positive News", "https://www.positive.news/feed/"}};

    private static final Map<String, List<AlertItem>> CACHE = new HashMap<>();
    private static final Map<String, Long> STAMP = new HashMap<>();

    public static synchronized void invalidate() {
        CACHE.clear();
        STAMP.clear();
    }

    private static synchronized List<AlertItem> cached(String type, long ttl) {
        Long t = STAMP.get(type);
        return (t != null && System.currentTimeMillis() - t < ttl) ? CACHE.get(type) : null;
    }

    private static synchronized void store(String type, List<AlertItem> l) {
        CACHE.put(type, l);
        STAMP.put(type, System.currentTimeMillis());
    }

    /** @param force true on pull-to-refresh: skip the cache (5 min for alerts, 15 min for news). */
    public static void load(Context ctx, String type, boolean force, Callback cb) {
        final Context app = ctx.getApplicationContext();
        IO.execute(() -> {
            long ttl = AlertItem.ALERT.equals(type) ? 5 * 60_000L : 15 * 60_000L;
            List<AlertItem> result = force ? null : cached(type, ttl);
            String err = null;

            if (result == null) {
                List<Callable<List<AlertItem>>> jobs = new ArrayList<>();
                if (AlertItem.ALERT.equals(type)) {
                    jobs.add(AlertRepository::fetchQuakes);
                    jobs.add(AlertRepository::fetchGdacs);
                } else {
                    boolean watch = AlertItem.WATCH.equals(type);
                    for (String[] feed : (watch ? WATCH_FEEDS : GOOD_FEEDS)) {
                        jobs.add(() -> RssParser.fetch(feed[1], feed[0], watch));
                    }
                }
                result = new ArrayList<>();
                int failures = 0;
                for (Callable<List<AlertItem>> job : jobs) {
                    try { result.addAll(job.call()); }
                    catch (Exception e) { err = String.valueOf(e.getMessage()); failures++; }
                }
                if (failures < jobs.size()) err = null;   // partial results are fine
                Collections.sort(result, (x, y) -> Long.compare(y.time, x.time));
                if (!AlertItem.ALERT.equals(type)) {
                    result = applyKeywords(app, result);
                    if (result.size() > 40) result = new ArrayList<>(result.subList(0, 40));
                }
                if (err == null) store(type, result);
            }

            final List<AlertItem> fr = result;
            final String fe = err;
            MAIN.post(() -> cb.onResult(fr, fe));
        });
    }

    /** Blocking fetch of alerts (earthquakes + GDACS); used by the background notification worker. */
    public static List<AlertItem> fetchAlertsBlocking() throws Exception {
        List<AlertItem> out = new ArrayList<>();
        Exception last = null;
        int fails = 0;
        try { out.addAll(fetchQuakes()); } catch (Exception e) { last = e; fails++; }
        try { out.addAll(fetchGdacs()); } catch (Exception e) { last = e; fails++; }
        if (fails == 2) throw last;
        return out;
    }

    /** Blocking fetch of breaking (HIGH severity) world headlines, honouring the user's keywords. */
    public static List<AlertItem> fetchBreakingBlocking(Context ctx) {
        List<AlertItem> out = new ArrayList<>();
        for (String[] feed : WATCH_FEEDS) {
            try {
                for (AlertItem a : RssParser.fetch(feed[1], feed[0], true)) {
                    if (a.severity >= AlertItem.HIGH) out.add(a);
                }
            } catch (Exception ignored) { }
        }
        return applyKeywords(ctx.getApplicationContext(), out);
    }

    private static List<AlertItem> applyKeywords(Context ctx, List<AlertItem> in) {
        String raw = Prefs.keywords(ctx).trim();
        if (raw.isEmpty()) return in;
        String[] ks = raw.toLowerCase(Locale.ROOT).split(",");
        List<AlertItem> out = new ArrayList<>();
        for (AlertItem a : in) {
            String hay = (a.title + " " + a.summary).toLowerCase(Locale.ROOT);
            for (String k : ks) {
                k = k.trim();
                if (!k.isEmpty() && hay.contains(k)) { out.add(a); break; }
            }
        }
        return out;
    }

    private static List<AlertItem> fetchQuakes() throws Exception {
        HttpURLConnection c = (HttpURLConnection) new URL(USGS).openConnection();
        c.setConnectTimeout(10000);
        c.setReadTimeout(10000);
        try (BufferedReader r = new BufferedReader(
                new InputStreamReader(c.getInputStream(), StandardCharsets.UTF_8))) {
            StringBuilder sb = new StringBuilder();
            String line;
            while ((line = r.readLine()) != null) sb.append(line);
            JSONArray features = new JSONObject(sb.toString()).getJSONArray("features");
            List<AlertItem> list = new ArrayList<>();
            for (int i = 0; i < features.length(); i++) {
                JSONObject p = features.getJSONObject(i).getJSONObject("properties");
                double mag = p.optDouble("mag", 0);
                int sev = mag >= 7 ? AlertItem.CRITICAL : mag >= 6 ? AlertItem.HIGH : AlertItem.MEDIUM;
                list.add(new AlertItem(
                        p.optString("title", "Earthquake"),
                        "Magnitude " + mag + " - " + p.optString("place", ""),
                        "USGS (official agency)",
                        p.optString("url", ""),
                        p.optLong("time", 0),
                        sev));
            }
            Collections.sort(list, (a, b) -> Long.compare(b.time, a.time));
            return list;
        } finally {
            c.disconnect();
        }
    }

    private static final String GDACS = "https://www.gdacs.org/xml/rss.xml";
    private static final Set<String> GDACS_FIELDS = new HashSet<>(Arrays.asList(
            "title", "link", "pubDate", "gdacs:alertlevel", "gdacs:eventtype",
            "gdacs:eventid", "gdacs:country"));

    private static List<AlertItem> fetchGdacs() throws Exception {
        HttpURLConnection c = (HttpURLConnection) new URL(GDACS).openConnection();
        c.setConnectTimeout(10000);
        c.setReadTimeout(15000);
        byte[] data;
        try (InputStream in = c.getInputStream()) {
            ByteArrayOutputStream bos = new ByteArrayOutputStream();
            byte[] buf = new byte[8192];
            int n;
            while ((n = in.read(buf)) > 0) bos.write(buf, 0, n);
            data = bos.toByteArray();
        } finally {
            c.disconnect();
        }
        int off = (data.length > 3 && (data[0] & 0xFF) == 0xEF && (data[1] & 0xFF) == 0xBB
                && (data[2] & 0xFF) == 0xBF) ? 3 : 0;   // strip UTF-8 BOM

        XmlPullParser p = Xml.newPullParser();
        p.setInput(new ByteArrayInputStream(data, off, data.length - off), "UTF-8");

        Map<String, AlertItem> byEvent = new HashMap<>();
        Map<String, String> f = new HashMap<>();
        int itemDepth = -1;
        int ev = p.getEventType();
        while (ev != XmlPullParser.END_DOCUMENT) {
            if (ev == XmlPullParser.START_TAG) {
                String n = p.getName();
                if (itemDepth < 0 && "item".equals(n)) {
                    itemDepth = p.getDepth();
                    f.clear();
                } else if (itemDepth >= 0 && p.getDepth() == itemDepth + 1 && GDACS_FIELDS.contains(n)) {
                    f.put(n, p.nextText().trim());
                }
            } else if (ev == XmlPullParser.END_TAG && itemDepth >= 0
                    && p.getDepth() == itemDepth && "item".equals(p.getName())) {
                addGdacs(byEvent, f);
                itemDepth = -1;
            }
            ev = p.next();
        }
        return new ArrayList<>(byEvent.values());
    }

    private static void addGdacs(Map<String, AlertItem> out, Map<String, String> f) {
        String type = f.getOrDefault("gdacs:eventtype", "");
        if (type.isEmpty() || "EQ".equals(type)) return;       // USGS already covers earthquakes
        String level = f.getOrDefault("gdacs:alertlevel", "Green");
        int sev = "Red".equalsIgnoreCase(level) ? AlertItem.CRITICAL
                : "Orange".equalsIgnoreCase(level) ? AlertItem.HIGH : AlertItem.MEDIUM;

        String country = f.getOrDefault("gdacs:country", "");
        String summary = eventName(type) + (country.isEmpty() ? "" : " - " + country)
                + " - GDACS " + level + " alert";
        String link = f.getOrDefault("link", "").replace("http://", "https://");

        long time = System.currentTimeMillis();
        try {
            time = new SimpleDateFormat("EEE, dd MMM yyyy HH:mm:ss z", Locale.US)
                    .parse(f.getOrDefault("pubDate", "")).getTime();
        } catch (Exception ignored) { }

        String key = type + f.getOrDefault("gdacs:eventid", f.getOrDefault("title", ""));
        out.put(key, new AlertItem(f.getOrDefault("title", "GDACS alert"), summary,
                "GDACS (UN / European Commission)", link, time, sev));
    }

    private static String eventName(String code) {
        switch (code) {
            case "TC": return "Tropical cyclone";
            case "FL": return "Flood";
            case "VO": return "Volcano";
            case "DR": return "Drought";
            case "WF": return "Wildfire";
            case "TS": return "Tsunami";
            default: return code;
        }
    }
}
