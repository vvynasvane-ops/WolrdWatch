package com.vvynas.worldwatch.ui;

import android.content.Context;
import android.content.res.Configuration;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.util.AttributeSet;
import android.view.View;

/** Faint cyber-grid drawn in the accent colour behind the feed. */
public class GridBackgroundView extends View {
    private final Paint paint = new Paint();

    public GridBackgroundView(Context c) { this(c, null); }

    public GridBackgroundView(Context c, AttributeSet a) {
        super(c, a);
        paint.setStrokeWidth(getResources().getDisplayMetrics().density);
    }

    @Override
    protected void onDraw(Canvas canvas) {
        boolean night = (getResources().getConfiguration().uiMode & Configuration.UI_MODE_NIGHT_MASK)
                == Configuration.UI_MODE_NIGHT_YES;
        paint.setColor(ThemeHelper.withAlpha(ThemeHelper.primary(getContext()), night ? 28 : 18));
        float step = 28 * getResources().getDisplayMetrics().density;
        for (float x = 0; x < getWidth(); x += step) canvas.drawLine(x, 0, x, getHeight(), paint);
        for (float y = 0; y < getHeight(); y += step) canvas.drawLine(0, y, getWidth(), y, paint);
    }
}
