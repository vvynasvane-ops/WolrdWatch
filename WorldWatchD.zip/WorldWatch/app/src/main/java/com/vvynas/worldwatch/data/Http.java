package com.vvynas.worldwatch.data;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;

/** Tiny HTTPS GET helper. Returns the body bytes with any UTF-8 BOM removed. */
public final class Http {
    private Http() {}

    public static byte[] get(String url) throws IOException {
        HttpURLConnection c = (HttpURLConnection) new URL(url).openConnection();
        c.setConnectTimeout(10000);
        c.setReadTimeout(15000);
        c.setRequestProperty("User-Agent", "WorldWatch/1.0 (Android)");
        c.setRequestProperty("Accept", "application/rss+xml, application/xml, application/json, */*");
        try {
            int code = c.getResponseCode();
            if (code != 200) throw new IOException("HTTP " + code);
            try (InputStream in = c.getInputStream()) {
                ByteArrayOutputStream bos = new ByteArrayOutputStream();
                byte[] buf = new byte[8192];
                int n;
                while ((n = in.read(buf)) > 0) bos.write(buf, 0, n);
                byte[] d = bos.toByteArray();
                if (d.length > 3 && (d[0] & 0xFF) == 0xEF && (d[1] & 0xFF) == 0xBB && (d[2] & 0xFF) == 0xBF) {
                    byte[] t = new byte[d.length - 3];
                    System.arraycopy(d, 3, t, 0, t.length);
                    return t;
                }
                return d;
            }
        } finally {
            c.disconnect();
        }
    }
}
