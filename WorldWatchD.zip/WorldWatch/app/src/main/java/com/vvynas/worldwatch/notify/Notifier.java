package com.vvynas.worldwatch.notify;

import android.Manifest;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;

import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;
import androidx.core.content.ContextCompat;

import com.vvynas.worldwatch.R;
import com.vvynas.worldwatch.data.Prefs;
import com.vvynas.worldwatch.model.AlertItem;
import com.vvynas.worldwatch.ui.MainActivity;
import com.vvynas.worldwatch.ui.ThemeHelper;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.List;

public final class Notifier {
    private Notifier() {}

    public static final String CH_CRITICAL = "ww_critical";
    public static final String CH_HIGH = "ww_high";
    public static final String CH_INFO = "ww_info";
    private static final String GROUP = "com.vvynas.worldwatch.ALERTS";
    private static final int SUMMARY_ID = 1;
    private static final int MAX_INDIVIDUAL = 5;

    public static void createChannels(Context c) {
        NotificationManager nm = c.getSystemService(NotificationManager.class);
        if (nm == null) return;
        NotificationChannel crit = new NotificationChannel(CH_CRITICAL,
                c.getString(R.string.ch_critical), NotificationManager.IMPORTANCE_HIGH);
        crit.setDescription(c.getString(R.string.ch_critical_desc));
        crit.enableVibration(true);
        crit.enableLights(true);
        NotificationChannel high = new NotificationChannel(CH_HIGH,
                c.getString(R.string.ch_high), NotificationManager.IMPORTANCE_DEFAULT);
        high.setDescription(c.getString(R.string.ch_high_desc));
        NotificationChannel info = new NotificationChannel(CH_INFO,
                c.getString(R.string.ch_info), NotificationManager.IMPORTANCE_LOW);
        info.setDescription(c.getString(R.string.ch_info_desc));
        nm.createNotificationChannel(crit);
        nm.createNotificationChannel(high);
        nm.createNotificationChannel(info);
    }

    /** True when the app is allowed to post (permission granted and not blocked in system settings). */
    public static boolean canPost(Context c) {
        if (Build.VERSION.SDK_INT >= 33 && ContextCompat.checkSelfPermission(c,
                Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            return false;
        }
        return NotificationManagerCompat.from(c).areNotificationsEnabled();
    }

    public static boolean inQuietHours(Context c) {
        if (!Prefs.quietOn(c)) return false;
        Calendar now = Calendar.getInstance();
        int m = now.get(Calendar.HOUR_OF_DAY) * 60 + now.get(Calendar.MINUTE);
        int s = Prefs.quietStart(c), e = Prefs.quietEnd(c);
        if (s == e) return false;
        return s < e ? (m >= s && m < e) : (m >= s || m < e);
    }

    public static void postTest(Context c) {
        long now = System.currentTimeMillis();
        List<AlertItem> l = new ArrayList<>();
        l.add(new AlertItem(c.getString(R.string.notif_test_title), c.getString(R.string.notif_test_body),
                "World Watch", "", now, AlertItem.CRITICAL));
        post(c, l);
    }

    /** Posts up to five individual notifications plus a summary when there are several. */
    public static void post(Context c, List<AlertItem> items) {
        if (items.isEmpty() || !canPost(c)) return;
        if (Build.VERSION.SDK_INT >= 33 && ContextCompat.checkSelfPermission(c,
                Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) return;

        List<AlertItem> sorted = new ArrayList<>(items);
        Collections.sort(sorted, (x, y) -> x.severity != y.severity
                ? Integer.compare(y.severity, x.severity) : Long.compare(y.time, x.time));

        NotificationManagerCompat nm = NotificationManagerCompat.from(c);
        int shown = Math.min(sorted.size(), MAX_INDIVIDUAL);
        for (int i = 0; i < shown; i++) nm.notify(idFor(sorted.get(i)), build(c, sorted.get(i)));

        if (sorted.size() > 1) {
            NotificationCompat.InboxStyle inbox = new NotificationCompat.InboxStyle();
            for (int i = 0; i < shown; i++) inbox.addLine(sorted.get(i).title);
            inbox.setSummaryText(c.getString(R.string.notif_summary, sorted.size()));
            postSummary(c, nm, inbox, sorted.size());
        }
    }

    private static void postSummary(Context c, NotificationManagerCompat nm,
                                             NotificationCompat.InboxStyle style, int total) {
        PendingIntent pi = openApp(c, 0, "alert");
        android.app.Notification n = new NotificationCompat.Builder(c, CH_HIGH)
                .setSmallIcon(R.drawable.ic_notif)
                .setContentTitle(c.getString(R.string.app_name))
                .setContentText(c.getString(R.string.notif_summary, total))
                .setStyle(style)
                .setColor(ThemeHelper.accentColor(c))
                .setGroup(GROUP)
                .setGroupSummary(true)
                .setAutoCancel(true)
                .setContentIntent(pi)
                .build();
        nm.notify(SUMMARY_ID, n);
    }

    private static int idFor(AlertItem a) {
        return 100 + (a.key().hashCode() & 0x0FFFFFFF);
    }

    private static PendingIntent openApp(Context c, int req, String tab) {
        Intent i = new Intent(c, MainActivity.class)
                .setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP)
                .putExtra(MainActivity.EXTRA_TAB, tab);
        return PendingIntent.getActivity(c, req, i,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
    }

    private static android.app.Notification build(Context c, AlertItem a) {
        int id = idFor(a);
        String channel = a.severity >= AlertItem.CRITICAL ? CH_CRITICAL
                : a.severity == AlertItem.HIGH ? CH_HIGH : CH_INFO;
        int label = a.severity >= AlertItem.CRITICAL ? R.string.sev_critical
                : a.severity == AlertItem.HIGH ? R.string.sev_high : R.string.sev_medium;
        int priority = a.severity >= AlertItem.CRITICAL ? NotificationCompat.PRIORITY_HIGH
                : a.severity == AlertItem.HIGH ? NotificationCompat.PRIORITY_DEFAULT
                : NotificationCompat.PRIORITY_LOW;

        NotificationCompat.Builder b = new NotificationCompat.Builder(c, channel)
                .setSmallIcon(R.drawable.ic_notif)
                .setContentTitle(a.title)
                .setContentText(a.summary)
                .setSubText(c.getString(label))
                .setStyle(new NotificationCompat.BigTextStyle().bigText(a.summary).setSummaryText(a.source))
                .setColor(ThemeHelper.accentColor(c))
                .setWhen(a.time)
                .setShowWhen(true)
                .setAutoCancel(true)
                .setCategory(NotificationCompat.CATEGORY_EVENT)
                .setPriority(priority)
                .setGroup(GROUP)
                .setContentIntent(openApp(c, id, a.news ? "watch" : "alert"));

        if (a.url != null && a.url.startsWith("https://")) {
            PendingIntent read = PendingIntent.getActivity(c, id + 1,
                    new Intent(Intent.ACTION_VIEW, Uri.parse(a.url)),
                    PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
            b.addAction(R.drawable.ic_globe, c.getString(R.string.notif_read), read);
        }
        return b.build();
    }
}
