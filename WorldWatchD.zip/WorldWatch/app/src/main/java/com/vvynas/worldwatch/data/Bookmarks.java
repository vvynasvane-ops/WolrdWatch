package com.vvynas.worldwatch.data;

import android.content.Context;

import com.vvynas.worldwatch.model.AlertItem;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/** Locally saved alerts, persisted as JSON in SharedPreferences. */
public final class Bookmarks {
    private Bookmarks() {}

    private static final String KEY = "bookmarks_json";
    private static final int MAX = 100;
    private static List<AlertItem> cache;
    private static Set<String> keys;

    private static synchronized void load(Context c) {
        if (cache != null) return;
        cache = new ArrayList<>();
        keys = new HashSet<>();
        try {
            JSONArray arr = new JSONArray(Prefs.sp(c).getString(KEY, "[]"));
            for (int i = 0; i < arr.length(); i++) {
                JSONObject o = arr.getJSONObject(i);
                AlertItem a = new AlertItem(o.optString("t"), o.optString("s"), o.optString("src"),
                        o.optString("u"), o.optLong("ti"), o.optInt("sv", 1), o.optBoolean("n"));
                cache.add(a);
                keys.add(a.key());
            }
        } catch (Exception ignored) { }
    }

    public static synchronized boolean isSaved(Context c, AlertItem a) {
        load(c);
        return keys.contains(a.key());
    }

    /** @return true if the item is saved after the toggle. */
    public static synchronized boolean toggle(Context c, AlertItem a) {
        load(c);
        boolean saved;
        if (keys.remove(a.key())) {
            for (int i = 0; i < cache.size(); i++) {
                if (cache.get(i).key().equals(a.key())) { cache.remove(i); break; }
            }
            saved = false;
        } else {
            cache.add(0, a);
            keys.add(a.key());
            while (cache.size() > MAX) keys.remove(cache.remove(cache.size() - 1).key());
            saved = true;
        }
        persist(c);
        return saved;
    }

    public static synchronized List<AlertItem> all(Context c) {
        load(c);
        List<AlertItem> copy = new ArrayList<>(cache);
        Collections.sort(copy, (x, y) -> Long.compare(y.time, x.time));
        return copy;
    }

    private static void persist(Context c) {
        try {
            JSONArray arr = new JSONArray();
            for (AlertItem a : cache) {
                JSONObject o = new JSONObject();
                o.put("t", a.title);
                o.put("s", a.summary);
                o.put("src", a.source);
                o.put("u", a.url);
                o.put("ti", a.time);
                o.put("sv", a.severity);
                o.put("n", a.news);
                arr.put(o);
            }
            Prefs.sp(c).edit().putString(KEY, arr.toString()).apply();
        } catch (Exception ignored) { }
    }
}
