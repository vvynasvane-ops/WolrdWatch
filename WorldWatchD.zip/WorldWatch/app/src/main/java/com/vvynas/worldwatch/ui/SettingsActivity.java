package com.vvynas.worldwatch.ui;

import android.Manifest;
import android.app.TimePickerDialog;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatDelegate;
import androidx.core.content.ContextCompat;

import com.google.android.material.button.MaterialButtonToggleGroup;
import com.google.android.material.materialswitch.MaterialSwitch;
import com.google.android.material.slider.Slider;
import com.vvynas.worldwatch.R;
import com.vvynas.worldwatch.data.Prefs;
import com.vvynas.worldwatch.notify.Notifier;
import com.vvynas.worldwatch.notify.NotifyScheduler;

import java.util.Locale;
import java.util.function.IntConsumer;

public class SettingsActivity extends BaseActivity {
    private boolean binding;
    private MaterialSwitch switchNotif;
    private View notifGroup;
    private Button quietStart, quietEnd;
    private TextView accentName, fontValue;

    private final ActivityResultLauncher<String> notifPermission =
            registerForActivityResult(new ActivityResultContracts.RequestPermission(), this::onNotifPermission);

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_settings);
        setSupportActionBar(findViewById(R.id.toolbar));
        if (getSupportActionBar() != null) getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        binding = true;
        bindAppearance();
        bindNotifications();
        bindFeed();
        binding = false;

        Fonts.apply(findViewById(android.R.id.content));
    }

    // ------------------------------------------------------------------ appearance

    private void bindAppearance() {
        segment(R.id.group_mode,
                new int[]{R.id.btn_mode_system, R.id.btn_mode_light, R.id.btn_mode_dark, R.id.btn_mode_amoled},
                Prefs.themeMode(this), i -> {
                    int before = AppCompatDelegate.getDefaultNightMode();
                    Prefs.setThemeMode(this, i);
                    ThemeHelper.applyNightMode(this);
                    // AppCompat rebuilds on its own when the day/night mode changes; Dark <-> AMOLED needs a nudge
                    if (AppCompatDelegate.getDefaultNightMode() == before) recreate();
                });

        buildAccentRow();

        Spinner font = findViewById(R.id.spinner_font);
        Typeface[] faces = new Typeface[Fonts.NAMES.length];
        for (int i = 0; i < faces.length; i++) faces[i] = Fonts.get(this, i);
        font.setAdapter(new TfAdapter(this, Fonts.NAMES, faces, null));
        font.setSelection(ThemeHelper.clamp(Prefs.font(this), Fonts.NAMES.length - 1));
        font.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override public void onItemSelected(AdapterView<?> p, View v, int pos, long id) {
                if (binding || pos == Prefs.font(SettingsActivity.this)) return;
                Prefs.setFont(SettingsActivity.this, pos);
                recreate();
            }
            @Override public void onNothingSelected(AdapterView<?> p) { }
        });

        final String[] scaleNames = getResources().getStringArray(R.array.font_scale_names);
        fontValue = findViewById(R.id.font_value);
        Slider slider = findViewById(R.id.slider_font);
        int idx = ThemeHelper.clamp(Prefs.fontScale(this), scaleNames.length - 1);
        slider.setValue(idx);
        fontValue.setText(scaleLabel(scaleNames, idx));
        slider.addOnChangeListener((s, value, fromUser) ->
                fontValue.setText(scaleLabel(scaleNames, (int) value)));
        slider.addOnSliderTouchListener(new Slider.OnSliderTouchListener() {
            @Override public void onStartTrackingTouch(Slider s) { }
            @Override public void onStopTrackingTouch(Slider s) {
                int v = (int) s.getValue();
                if (v == Prefs.fontScale(SettingsActivity.this)) return;
                Prefs.setFontScale(SettingsActivity.this, v);
                recreate();
            }
        });

        segment(R.id.group_density, new int[]{R.id.btn_density_comfy, R.id.btn_density_compact},
                Prefs.density(this), i -> Prefs.setDensity(this, i));
        segment(R.id.group_shape, new int[]{R.id.btn_shape_sharp, R.id.btn_shape_soft, R.id.btn_shape_round},
                Prefs.shape(this), i -> Prefs.setShape(this, i));
        segment(R.id.group_unit, new int[]{R.id.btn_unit_c, R.id.btn_unit_f},
                Prefs.tempF(this) ? 1 : 0, i -> Prefs.setTempF(this, i == 1));

        MaterialSwitch motion = findViewById(R.id.switch_motion);
        motion.setChecked(Prefs.reduceMotion(this));
        motion.setOnCheckedChangeListener((b, on) -> { if (!binding) Prefs.setReduceMotion(this, on); });
        MaterialSwitch haptics = findViewById(R.id.switch_haptics);
        haptics.setChecked(Prefs.haptics(this));
        haptics.setOnCheckedChangeListener((b, on) -> { if (!binding) Prefs.setHaptics(this, on); });
    }

    private String scaleLabel(String[] names, int i) {
        int pct = Math.round(ThemeHelper.FONT_SCALES[ThemeHelper.clamp(i, names.length - 1)] * 100);
        return names[ThemeHelper.clamp(i, names.length - 1)] + " \u2022 " + pct + "%";
    }

    private void buildAccentRow() {
        LinearLayout row = findViewById(R.id.accent_row);
        accentName = findViewById(R.id.accent_name);
        final int current = ThemeHelper.clamp(Prefs.accent(this), ThemeHelper.ACCENT_SWATCH.length - 1);
        accentName.setText(ThemeHelper.ACCENT_NAMES[current]);
        final float dp = getResources().getDisplayMetrics().density;
        final int ring = ThemeHelper.color(this, com.google.android.material.R.attr.colorOnSurface, 0xFFFFFFFF);
        for (int i = 0; i < ThemeHelper.ACCENT_SWATCH.length; i++) {
            final int index = i;
            View s = new View(this);
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams((int) (44 * dp), (int) (44 * dp));
            lp.setMargins(0, 0, (int) (12 * dp), 0);
            s.setLayoutParams(lp);
            GradientDrawable d = new GradientDrawable();
            d.setShape(GradientDrawable.OVAL);
            d.setColor(ThemeHelper.ACCENT_SWATCH[i]);
            if (i == current) d.setStroke((int) (3 * dp), ring);
            s.setBackground(d);
            s.setContentDescription(ThemeHelper.ACCENT_NAMES[i]);
            s.setOnClickListener(v -> {
                if (index == Prefs.accent(this)) return;
                ThemeHelper.haptic(v);
                Prefs.setAccent(this, index);
                recreate();
            });
            row.addView(s);
        }
    }

    // ------------------------------------------------------------------ notifications

    private void bindNotifications() {
        notifGroup = findViewById(R.id.notif_group);
        switchNotif = findViewById(R.id.switch_notif);
        switchNotif.setChecked(Prefs.notifEnabled(this));
        setEnabledDeep(notifGroup, Prefs.notifEnabled(this));
        switchNotif.setOnCheckedChangeListener((b, on) -> {
            if (binding) return;
            if (on && Build.VERSION.SDK_INT >= 33 && ContextCompat.checkSelfPermission(this,
                    Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
                notifPermission.launch(Manifest.permission.POST_NOTIFICATIONS);
            } else {
                setNotifications(on);
            }
        });

        Spinner sev = findViewById(R.id.spinner_notif_sev);
        sev.setAdapter(new TfAdapter(this, getResources().getStringArray(R.array.notif_severity_options),
                null, Fonts.current(this)));
        sev.setSelection(ThemeHelper.clamp(Prefs.notifMinSeverity(this) - 1, 2));
        sev.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override public void onItemSelected(AdapterView<?> p, View v, int pos, long id) {
                if (binding || pos + 1 == Prefs.notifMinSeverity(SettingsActivity.this)) return;
                Prefs.setNotifMinSeverity(SettingsActivity.this, pos + 1);
            }
            @Override public void onNothingSelected(AdapterView<?> p) { }
        });

        MaterialSwitch news = findViewById(R.id.switch_notif_news);
        news.setChecked(Prefs.notifNews(this));
        news.setOnCheckedChangeListener((b, on) -> { if (!binding) Prefs.setNotifNews(this, on); });

        Spinner interval = findViewById(R.id.spinner_interval);
        interval.setAdapter(new TfAdapter(this, getResources().getStringArray(R.array.interval_options),
                null, Fonts.current(this)));
        interval.setSelection(ThemeHelper.clamp(Prefs.notifInterval(this), 4));
        interval.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override public void onItemSelected(AdapterView<?> p, View v, int pos, long id) {
                if (binding || pos == Prefs.notifInterval(SettingsActivity.this)) return;
                Prefs.setNotifInterval(SettingsActivity.this, pos);
                NotifyScheduler.schedule(SettingsActivity.this);
            }
            @Override public void onNothingSelected(AdapterView<?> p) { }
        });

        MaterialSwitch quiet = findViewById(R.id.switch_quiet);
        quiet.setChecked(Prefs.quietOn(this));
        quiet.setOnCheckedChangeListener((b, on) -> { if (!binding) Prefs.setQuietOn(this, on); });
        quietStart = findViewById(R.id.btn_quiet_start);
        quietEnd = findViewById(R.id.btn_quiet_end);
        refreshQuietLabels();
        quietStart.setOnClickListener(v -> pickTime(Prefs.quietStart(this), m -> Prefs.setQuietStart(this, m)));
        quietEnd.setOnClickListener(v -> pickTime(Prefs.quietEnd(this), m -> Prefs.setQuietEnd(this, m)));

        findViewById(R.id.btn_test_notif).setOnClickListener(v -> {
            if (!Notifier.canPost(this)) {
                Toast.makeText(this, R.string.notif_blocked, Toast.LENGTH_LONG).show();
                openSystemNotificationSettings();
            } else {
                Notifier.postTest(this);
            }
        });
        findViewById(R.id.btn_sys_notif).setOnClickListener(v -> openSystemNotificationSettings());
    }

    private void onNotifPermission(boolean granted) {
        if (granted) {
            setNotifications(true);
        } else {
            binding = true;
            if (switchNotif != null) switchNotif.setChecked(false);
            binding = false;
            Toast.makeText(this, R.string.notif_denied, Toast.LENGTH_SHORT).show();
        }
    }

    private void setNotifications(boolean on) {
        Prefs.setNotifEnabled(this, on);
        if (on) Prefs.setSeenInit(this, false);   // next check only records what already exists
        setEnabledDeep(notifGroup, on);
        NotifyScheduler.schedule(this);
    }

    private void pickTime(int minutes, IntConsumer onPicked) {
        new TimePickerDialog(this, (view, h, m) -> {
            onPicked.accept(h * 60 + m);
            refreshQuietLabels();
        }, minutes / 60, minutes % 60, true).show();
    }

    private void refreshQuietLabels() {
        quietStart.setText(getString(R.string.quiet_from, clock(Prefs.quietStart(this))));
        quietEnd.setText(getString(R.string.quiet_to, clock(Prefs.quietEnd(this))));
    }

    private static String clock(int minutes) {
        return String.format(Locale.US, "%02d:%02d", minutes / 60, minutes % 60);
    }

    private void openSystemNotificationSettings() {
        Intent i = new Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS)
                .putExtra(Settings.EXTRA_APP_PACKAGE, getPackageName());
        startActivity(i);
    }

    private static void setEnabledDeep(View v, boolean enabled) {
        v.setEnabled(enabled);
        v.setAlpha(enabled ? 1f : 0.45f);
        if (v instanceof ViewGroup) {
            ViewGroup g = (ViewGroup) v;
            for (int i = 0; i < g.getChildCount(); i++) setEnabledDeep(g.getChildAt(i), enabled);
        }
    }

    // ------------------------------------------------------------------ feed

    private void bindFeed() {
        final Spinner sev = findViewById(R.id.spinner_severity);
        final EditText city = findViewById(R.id.edit_city);
        final EditText keywords = findViewById(R.id.edit_keywords);
        sev.setAdapter(new TfAdapter(this, getResources().getStringArray(R.array.severity_options),
                null, Fonts.current(this)));
        sev.setSelection(Math.max(0, Prefs.minSeverity(this) - 1));
        city.setText(Prefs.city(this));
        keywords.setText(Prefs.keywords(this));

        findViewById(R.id.btn_save).setOnClickListener(v -> {
            Prefs.save(this, sev.getSelectedItemPosition() + 1,
                    city.getText().toString(), keywords.getText().toString());
            Toast.makeText(this, R.string.saved_toast, Toast.LENGTH_SHORT).show();
            finish();
        });
    }

    // ------------------------------------------------------------------ helpers

    private void segment(int groupId, final int[] buttonIds, int current, final IntConsumer onChange) {
        MaterialButtonToggleGroup g = findViewById(groupId);
        g.check(buttonIds[ThemeHelper.clamp(current, buttonIds.length - 1)]);
        g.addOnButtonCheckedListener((grp, checkedId, isChecked) -> {
            if (!isChecked || binding) return;
            for (int i = 0; i < buttonIds.length; i++) {
                if (buttonIds[i] == checkedId) {
                    ThemeHelper.haptic(grp);
                    onChange.accept(i);
                    break;
                }
            }
        });
    }

    @Override
    public boolean onSupportNavigateUp() {
        finish();
        return true;
    }

    /** Spinner adapter that renders each row in a chosen typeface. */
    private static class TfAdapter extends ArrayAdapter<String> {
        private final Typeface[] perItem;
        private final Typeface fallback;

        TfAdapter(android.content.Context c, String[] items, Typeface[] perItem, Typeface fallback) {
            super(c, android.R.layout.simple_spinner_item, items);
            setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
            this.perItem = perItem;
            this.fallback = fallback;
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            return style(super.getView(position, convertView, parent), position);
        }

        @Override
        public View getDropDownView(int position, View convertView, ViewGroup parent) {
            return style(super.getDropDownView(position, convertView, parent), position);
        }

        private View style(View v, int position) {
            Typeface tf = perItem != null ? perItem[position] : fallback;
            if (tf != null && v instanceof TextView) ((TextView) v).setTypeface(tf);
            return v;
        }
    }
}
