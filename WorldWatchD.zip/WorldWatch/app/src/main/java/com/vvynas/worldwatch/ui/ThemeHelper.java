package com.vvynas.worldwatch.ui;

import android.app.Activity;
import android.content.Context;
import android.content.res.Configuration;
import android.view.HapticFeedbackConstants;
import android.view.View;

import androidx.appcompat.app.AppCompatDelegate;

import com.google.android.material.color.MaterialColors;
import com.vvynas.worldwatch.R;
import com.vvynas.worldwatch.data.Prefs;

/** Central place for theme mode, accent overlays, font scale and small style helpers. */
public final class ThemeHelper {
    private ThemeHelper() {}

    public static final String[] ACCENT_NAMES =
            {"Cyber Cyan", "Nebula", "Solar", "Matrix", "Plasma", "Ion"};
    public static final int[] ACCENT_SWATCH =
            {0xFF22E5FF, 0xFFB388FF, 0xFFFFC247, 0xFF4DFF88, 0xFFFF4FD8, 0xFF5C9DFF};
    private static final int[] ACCENT_STYLE = {
            R.style.ThemeOverlay_WW_Cyan, R.style.ThemeOverlay_WW_Violet, R.style.ThemeOverlay_WW_Amber,
            R.style.ThemeOverlay_WW_Green, R.style.ThemeOverlay_WW_Magenta, R.style.ThemeOverlay_WW_Blue};

    public static final float[] FONT_SCALES = {0.85f, 1.0f, 1.15f, 1.3f, 1.5f};

    /** Card corner radius in dp for Sharp / Soft / Round. */
    private static final int[] CORNERS_DP = {2, 14, 28};

    public static int clamp(int v, int max) { return Math.max(0, Math.min(max, v)); }

    public static void applyNightMode(Context c) {
        int m;
        switch (Prefs.themeMode(c)) {
            case Prefs.MODE_LIGHT: m = AppCompatDelegate.MODE_NIGHT_NO; break;
            case Prefs.MODE_DARK:
            case Prefs.MODE_AMOLED: m = AppCompatDelegate.MODE_NIGHT_YES; break;
            default: m = AppCompatDelegate.MODE_NIGHT_FOLLOW_SYSTEM;
        }
        AppCompatDelegate.setDefaultNightMode(m);
    }

    /** Call in onCreate before super.onCreate(). */
    public static void applyOverlays(Activity a) {
        int accent = clamp(Prefs.accent(a), ACCENT_STYLE.length - 1);
        a.getTheme().applyStyle(ACCENT_STYLE[accent], true);
        if (Prefs.themeMode(a) == Prefs.MODE_AMOLED) {
            a.getTheme().applyStyle(R.style.ThemeOverlay_WW_Amoled, true);
        }
    }

    /** Wraps the base context with the user's font-size multiplier (on top of the system font scale). */
    public static Context withFontScale(Context base) {
        float mult = FONT_SCALES[clamp(Prefs.fontScale(base), FONT_SCALES.length - 1)];
        if (mult == 1f) return base;
        Configuration cfg = new Configuration(base.getResources().getConfiguration());
        cfg.fontScale = cfg.fontScale * mult;
        return base.createConfigurationContext(cfg);
    }

    /** Changes whenever a preference that needs the UI to be rebuilt changes. */
    public static String stamp(Context c) {
        return Prefs.themeMode(c) + "|" + Prefs.accent(c) + "|" + Prefs.font(c) + "|"
                + Prefs.fontScale(c) + "|" + Prefs.density(c) + "|" + Prefs.shape(c) + "|"
                + Prefs.tempF(c) + "|" + Prefs.reduceMotion(c);
    }

    public static int accentColor(Context c) {
        return ACCENT_SWATCH[clamp(Prefs.accent(c), ACCENT_SWATCH.length - 1)];
    }

    public static float cornerDp(int shape) {
        return CORNERS_DP[clamp(shape, CORNERS_DP.length - 1)];
    }

    public static int color(Context c, int attr, int fallback) {
        return MaterialColors.getColor(c, attr, fallback);
    }

    public static int primary(Context c) {
        return color(c, com.google.android.material.R.attr.colorPrimary, accentColor(c));
    }

    public static void haptic(View v) {
        if (Prefs.haptics(v.getContext())) v.performHapticFeedback(HapticFeedbackConstants.VIRTUAL_KEY);
    }

    public static int withAlpha(int color, int alpha) {
        return (color & 0x00FFFFFF) | (alpha << 24);
    }
}
